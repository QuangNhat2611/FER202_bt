export default function TaskItem({ task, onToggleTask, onDeleteTask }) {

  return (

    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 0', borderBottom: '1px dashed #eee' }}>

      <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer', textDecoration: task.completed ? 'line-through' : 'none', opacity: task.completed ? 0.6 : 1 }}>

        <input

          type="checkbox"

          checked={task.completed}

          onChange={() => onToggleTask(task.id)}

        />

        {task.title}

      </label>

      <button 

        onClick={() => onDeleteTask(task.id)}

        style={{ background: 'none', border: 'none', color: '#ff4d4f', cursor: 'pointer', padding: '2px 5px' }}

      >

        [Xóa]

      </button>

    </div>

  );

}
