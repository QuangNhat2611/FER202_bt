import { useTheme } from '../context/ThemeContext';

export default function Header() {

  const { isDarkMode, toggleTheme } = useTheme();

  return (

    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #ccc', paddingBottom: '10px', marginBottom: '15px' }}>

      <h2 style={{ margin: 0 }}>Mini Task Manager</h2>

      <button 

        onClick={toggleTheme}

        style={{ cursor: 'pointer', padding: '5px 10px', background: 'transparent', border: '1px solid currentColor', borderRadius: '4px', color: 'inherit' }}

      >

        {isDarkMode ? '🌙 Dark' : '☀️ Light'}

      </button>

    </div>

  );

}
