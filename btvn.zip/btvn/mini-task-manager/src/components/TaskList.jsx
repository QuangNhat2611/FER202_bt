import TaskItem from './TaskItem';

export default function TaskList({ tasks, onToggleTask, onDeleteTask }) {

  const total = tasks.length;

  const completedCount = tasks.filter((t) => t.completed).length;

  const activeCount = total - completedCount;

  return (

    <div>

      <div style={{ marginBottom: '15px', fontSize: '14px', fontWeight: 'bold' }}>

        Tổng: {total} | Chưa làm: {activeCount} | Hoàn thành: {completedCount}

      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>

        {tasks.length === 0 ? (

          <p style={{ textAlign: 'center', color: '#888' }}>Không tìm thấy công việc nào.</p>

        ) : (

          tasks.map((task) => (

            <TaskItem

              key={task.id}

              task={task}

              onToggleTask={onToggleTask}

              onDeleteTask={onDeleteTask}

            />

          ))

        )}

      </div>

    </div>

  );

}
