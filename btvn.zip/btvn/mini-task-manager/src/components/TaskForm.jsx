import { useState } from 'react';

export default function TaskForm({ onAddTask, searchTerm, setSearchTerm, filterStatus, setFilterStatus }) {

  const [title, setTitle] = useState('');

  const handleSubmit = (e) => {

    e.preventDefault();

    if (!title.trim()) return;

    onAddTask(title);

    setTitle('');

  };

  return (

    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '15px' }}>

      <form onSubmit={handleSubmit} style={{ display: 'flex', gap: '10px' }}>

        <input

          type="text"

          placeholder="Nhập tên công việc..."

          value={title}

          onChange={(e) => setTitle(e.target.value)}

          style={{ flex: 1, padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}

        />

        <button type="submit" style={{ padding: '8px 15px', cursor: 'pointer' }}>Thêm</button>

      </form>

      <div style={{ display: 'flex', gap: '10px' }}>

        <select

          value={filterStatus}

          onChange={(e) => setFilterStatus(e.target.value)}

          style={{ padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}

        >

          <option value="all">Tất cả</option>

          <option value="active">Chưa làm</option>

          <option value="completed">Hoàn thành</option>

        </select>

        <input

          type="text"

          placeholder="Tìm kiếm..."

          value={searchTerm}

          onChange={(e) => setSearchTerm(e.target.value)}

          style={{ flex: 1, padding: '8px', borderRadius: '4px', border: '1px solid #ccc' }}

        />

      </div>

    </div>

  );

}
