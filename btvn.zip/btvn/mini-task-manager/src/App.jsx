import { useState } from 'react';

import { ThemeProvider, useTheme } from './context/ThemeContext';

import { useLocalStorage } from './hooks/useLocalStorage';

import { initialTasks } from './tasks';

import Header from './components/Header';

import TaskForm from './components/TaskForm';

import TaskList from './components/TaskList';

function AppContent() {

  const { isDarkMode } = useTheme();

  const [tasks, setTasks] = useLocalStorage('manager_tasks', initialTasks);

  const [searchTerm, setSearchTerm] = useState('');

  const [filterStatus, setFilterStatus] = useState('all');

  const handleAddTask = (title) => {

    const newTask = {

      id: Date.now(),

      title,

      completed: false,

    };

    setTasks([newTask, ...tasks]);

  };

  const handleToggleTask = (id) => {

    setTasks(

      tasks.map((task) =>

        task.id === id ? { ...task, completed: !task.completed } : task

      )

    );

  };

  const handleDeleteTask = (id) => {

    setTasks(tasks.filter((task) => task.id !== id));

  };

  const filteredTasks = tasks.filter((task) => {

    const matchesSearch = task.title.toLowerCase().includes(searchTerm.toLowerCase());

    if (filterStatus === 'active') return matchesSearch && !task.completed;

    if (filterStatus === 'completed') return matchesSearch && task.completed;

    return matchesSearch;

  });

  const appStyle = {

    maxWidth: '450px',

    margin: '30px auto',

    padding: '20px',

    borderRadius: '8px',

    border: '1px solid',

    borderColor: isDarkMode ? '#444' : '#ccc',

    backgroundColor: isDarkMode ? '#1e1e1e' : '#fdfdfd',

    color: isDarkMode ? '#f1f1f1' : '#333',

    fontFamily: 'sans-serif',

    boxShadow: '0 4px 12px rgba(0,0,0,0.1)'

  };

  return (

    <div style={appStyle}>

      <Header />

      <TaskForm

        onAddTask={handleAddTask}

        searchTerm={searchTerm}

        setSearchTerm={setSearchTerm}

        filterStatus={filterStatus}

        setFilterStatus={setFilterStatus}

      />

      <TaskList

        tasks={filteredTasks}

        onToggleTask={handleToggleTask}

        onDeleteTask={handleDeleteTask}

      />

    </div>

  );

}

export default function App() {

  return (

    <ThemeProvider>

      <AppContent />

    </ThemeProvider>

  );

}
