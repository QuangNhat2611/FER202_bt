import { createContext, useContext } from 'react';

import { useLocalStorage } from '../hooks/useLocalStorage';

const ThemeContext = createContext();

export function ThemeProvider({ children }) {

  const [isDarkMode, setIsDarkMode] = useLocalStorage('app_theme', false);

  const toggleTheme = () => {

    setIsDarkMode((prev) => !prev);

  };

  return (

    <ThemeContext.Provider value={{ isDarkMode, toggleTheme }}>

      {children}

    </ThemeContext.Provider>

  );

}

export function useTheme() {

  return useContext(ThemeContext);

}
